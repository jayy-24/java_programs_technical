
public interface Shape {
    double area(); 
    double perimeter(); 
}
