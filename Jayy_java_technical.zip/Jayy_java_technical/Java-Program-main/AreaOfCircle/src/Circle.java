public class Circle {
    // Declare a final variable for PI
    public static final double PI = 3.14159;

    // Method to calculate the area of the circle
    public double calculateArea(double radius) {
        return PI * radius * radius;
    }
}
