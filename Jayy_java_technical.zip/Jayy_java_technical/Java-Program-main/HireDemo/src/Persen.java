
public class Persen {
	private String Name,City;

	public String getName() {
		return Name;
	}

	public void setNaxme(String name) {
		Name = name;
	}

	public String getCity() {
		return City;
	}

	public void setCity(String city) {
		City = city;
	}
	
	
}
