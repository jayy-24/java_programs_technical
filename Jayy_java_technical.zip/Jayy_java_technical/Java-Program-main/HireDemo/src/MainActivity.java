import java.util.Scanner;

public class MainActivity extends Persen {

	public static void main(String[] args) {
		
		
	}

}
