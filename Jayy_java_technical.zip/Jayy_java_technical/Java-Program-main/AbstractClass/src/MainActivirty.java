
public class MainActivirty {
	public static void main(String[] args) {
        Cats myCat = new Cats();
        Dogs myDog = new Dogs();

        myCat.cats(); 
        myDog.dogs(); 
    }
}
