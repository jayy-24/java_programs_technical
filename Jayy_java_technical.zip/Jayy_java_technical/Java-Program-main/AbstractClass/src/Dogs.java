class Dogs extends Animals {
    @Override
    void cats() {
        // Method not implemented for Dogs class
    }

    @Override
    void dogs() {
        System.out.println("Dogs bark");
    }
}
