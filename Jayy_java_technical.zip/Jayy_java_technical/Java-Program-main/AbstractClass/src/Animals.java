abstract class Animals {
    abstract void cats();
    abstract void dogs();
}
