
public class Emp_Details {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
